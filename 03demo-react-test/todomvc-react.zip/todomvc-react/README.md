## 项目构建
使用官方脚手架[Create React App](https://github.com/facebookincubator/create-react-app)进行构建.

## 主要技术
redux,react-route

## [create-component-app](https://github.com/CVarisco/create-component-app)
一款命令式创建的react组件的库,非常方便,更多完善值得期待.
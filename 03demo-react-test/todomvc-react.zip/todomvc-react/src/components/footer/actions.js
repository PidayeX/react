import {CLEAR_COMPLETED} from '../../action-types'

export const clearCompletedAction = () => ({
    type: CLEAR_COMPLETED,
    payload: null
})
